<?php
/**
 * Plugin Name: OmniXEP WooCommerce Payment Gateway
 * Plugin URI: https://www.electraprotocol.com/omnixep/
 * Description: Accept XEP and Tokens via OmniXEP Wallet.
 * Version: 1.8.2
 * Author: OmniXEP
 * Author URI: https://www.electraprotocol.com/omnixep/
 * Text Domain: omnixep-woocommerce
 * Domain Path: /i18n/languages/
 *
 * Requires at least: 5.8
 * Requires PHP: 7.4
 *
 * WC requires at least: 5.8
 * WC tested up to: 8.5
 */

defined('ABSPATH') || exit;

/**
 * Declare compatibility with WooCommerce HPOS (High-Performance Order Storage)
 */
add_action('before_woocommerce_init', function () {
    if (class_exists(\Automattic\WooCommerce\Utilities\FeaturesUtil::class)) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
    }
});

// Make sure WooCommerce is active
if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    return;
}

/**
 * Add the gateway to WC Available Gateways
 * 
 * @param array $gateways all available WC gateways
 * @return array $gateways all WC gateways + omnixep
 */
function wc_omnixep_add_to_gateways($gateways)
{
    if (class_exists('WC_Payment_Gateway')) { // Check if WC class exists to avoid fatal errors
        $gateways[] = 'WC_Gateway_Omnixep';
    }
    return $gateways;
}
add_filter('woocommerce_payment_gateways', 'wc_omnixep_add_to_gateways');

/**
 * Initialize Gateway Class with Integrity Check
 */
function wc_omnixep_init_gateway_class()
{
    $gateway_file = plugin_dir_path(__FILE__) . 'includes/class-wc-gateway-omnixep.php';

    // Integrity Verification Code - Updated after customization
    // Integrity Verification Code - DISABLED FOR DEVELOPMENT
    // $v_hash = '7da8ddc91fc423eff12505540d29a39e';
    // if (file_exists($gateway_file)) {
    //     $c_hash = md5_file($gateway_file);
    //     if (strcasecmp($c_hash, $v_hash) !== 0) {
    //         if (is_admin()) {
    //             add_action('admin_notices', function () {
    //                 echo '<div class="notice notice-error" style="border-left-width: 5px; border-left-color: #d63638;"><p><strong>🛡️ OmniXEP Security Alert:</strong> Plugin integrity check failed (Fingerprint Mismatch). The module has been modified and is disabled for protection. Please reinstall the original version.</p></div>';
    //             });
    //         }
    //         return;
    //     }
    // }

    if (class_exists('WC_Payment_Gateway')) {
        require_once $gateway_file;
    }
}
add_action('plugins_loaded', 'wc_omnixep_init_gateway_class', 11);

/**
 * Handle AJAX for Module Balance & Debt (Ensures hooks work even if gateway isn't instantiated)
 */
add_action('wp_ajax_omnixep_fetch_balance', 'wc_omnixep_ajax_fetch_balance_handler');
add_action('wp_ajax_omnixep_fetch_utxos', 'wc_omnixep_ajax_fetch_utxos_handler');
add_action('wp_ajax_omnixep_get_pending_debt', 'wc_omnixep_ajax_get_pending_debt_handler');
add_action('wp_ajax_omnixep_settle_debt', 'wc_omnixep_ajax_settle_debt_handler');
add_action('wp_ajax_omnixep_api_proxy', 'wc_omnixep_ajax_api_proxy_handler');
add_action('wp_ajax_omnixep_broadcast_tx', 'wc_omnixep_ajax_broadcast_tx_handler');

// Mobile Payment AJAX Handlers
add_action('wp_ajax_omnixep_check_mobile_payment', 'wc_omnixep_check_mobile_payment');
add_action('wp_ajax_nopriv_omnixep_check_mobile_payment', 'wc_omnixep_check_mobile_payment');
add_action('wp_ajax_omnixep_save_mobile_txid', 'wc_omnixep_save_mobile_txid');
add_action('wp_ajax_nopriv_omnixep_save_mobile_txid', 'wc_omnixep_save_mobile_txid');

// Mobile Callback Handler (wallet app redirects here after payment)
add_action('template_redirect', 'wc_omnixep_mobile_callback_handler');

function wc_omnixep_mobile_callback_handler()
{
    if (!isset($_GET['omnixep_mobile_callback']))
        return;

    $order_id = isset($_GET['order_id']) ? intval($_GET['order_id']) : 0;
    $order_key = isset($_GET['key']) ? sanitize_text_field($_GET['key']) : '';
    $txid = isset($_GET['omnixep_txid']) ? sanitize_text_field($_GET['omnixep_txid']) : '';

    if (!$order_id || !$order_key || !$txid) {
        wp_die('Invalid mobile callback parameters.');
    }

    if (!preg_match('/^[a-fA-F0-9]{64}$/', $txid)) {
        wp_die('Invalid transaction ID format.');
    }

    $order = wc_get_order($order_id);
    if (!$order || $order->get_order_key() !== $order_key) {
        wp_die('Invalid order.');
    }

    $existing_txid = $order->get_meta('_omnixep_txid');
    if (!empty($existing_txid)) {
        wp_redirect($order->get_checkout_order_received_url());
        exit;
    }

    $platform = isset($_GET['omnixep_platform']) ? sanitize_text_field($_GET['omnixep_platform']) : 'Mobile';

    $order->update_meta_data('_omnixep_txid', $txid);
    $order->update_meta_data('_omnixep_mobile_pending', '');
    $order->update_meta_data('_omnixep_platform', $platform);
    $order->update_status('pending-crypto', 'Mobile wallet payment successful (' . esc_html($platform) . '). Transaction ID: ' . esc_html($txid));
    $order->save();

    if (function_exists('as_schedule_single_action')) {
        as_schedule_single_action(time() + 15, 'omnixep_verify_single_order', array($order_id));
    }

    error_log('OmniXEP Mobile Callback: TXID saved for Order #' . $order_id . ' - ' . $txid . ' (Platform: ' . $platform . ')');
    wp_redirect($order->get_checkout_order_received_url());
    exit;
}

function wc_omnixep_check_mobile_payment()
{
    $order_id = isset($_REQUEST['order_id']) ? intval($_REQUEST['order_id']) : 0;
    $order_key = isset($_REQUEST['key']) ? sanitize_text_field($_REQUEST['key']) : '';
    $nonce = isset($_REQUEST['_wpnonce']) ? sanitize_text_field($_REQUEST['_wpnonce']) : '';

    if (!$order_id || !$order_key || !wp_verify_nonce($nonce, 'omnixep_mobile_nonce_' . $order_id)) {
        wp_send_json_error('Security check failed');
    }

    // Rate limiting
    $rl_key = 'omnixep_rl_mobile_' . $order_id;
    $attempts = (int) get_transient($rl_key);
    if ($attempts > 10) {
        wp_send_json_error('Too many requests');
    }
    set_transient($rl_key, $attempts + 1, 60);

    if (!$order_id || !$order_key) {
        wp_send_json_error('Missing parameters');
    }

    $order = wc_get_order($order_id);
    if (!$order || $order->get_order_key() !== $order_key) {
        wp_send_json_error('Invalid order');
    }

    $txid = $order->get_meta('_omnixep_txid');
    if (!empty($txid)) {
        wp_send_json_success(array('has_txid' => true, 'status' => $order->get_status(), 'redirect' => $order->get_checkout_order_received_url()));
    }
    wp_send_json_success(array('has_txid' => false, 'status' => $order->get_status()));
}

function wc_omnixep_save_mobile_txid()
{
    $order_id = isset($_REQUEST['order_id']) ? intval($_REQUEST['order_id']) : 0;
    $order_key = isset($_REQUEST['key']) ? sanitize_text_field($_REQUEST['key']) : '';
    $txid = isset($_REQUEST['txid']) ? sanitize_text_field($_REQUEST['txid']) : '';
    $nonce = isset($_REQUEST['_wpnonce']) ? sanitize_text_field($_REQUEST['_wpnonce']) : '';

    if (!$order_id || !$order_key || !wp_verify_nonce($nonce, 'omnixep_mobile_nonce_' . $order_id)) {
        wp_send_json_error('Security check failed');
    }

    // Rate limiting
    $rl_key = 'omnixep_rl_mobile_save_' . $order_id;
    $attempts = (int) get_transient($rl_key);
    if ($attempts > 5) {
        wp_send_json_error('Too many requests');
    }
    set_transient($rl_key, $attempts + 1, 60);

    if (!$order_id || !$order_key || !$txid) {
        wp_send_json_error('Missing parameters');
    }
    if (!preg_match('/^[a-fA-F0-9]{64}$/', $txid)) {
        wp_send_json_error('Invalid TXID');
    }

    $order = wc_get_order($order_id);
    if (!$order || $order->get_order_key() !== $order_key) {
        wp_send_json_error('Invalid order');
    }

    $existing = $order->get_meta('_omnixep_txid');
    if (!empty($existing)) {
        wp_send_json_success(array('redirect' => $order->get_checkout_order_received_url()));
        return;
    }

    $platform = isset($_GET['platform']) ? sanitize_text_field($_GET['platform']) : 'Mobile';

    $order->update_meta_data('_omnixep_txid', $txid);
    $order->update_meta_data('_omnixep_mobile_pending', '');
    $order->update_meta_data('_omnixep_platform', $platform);
    $order->add_order_note('In-app browser payment received (' . esc_html($platform) . '). TXID: ' . esc_html($txid));
    $order->save();

    if (function_exists('as_schedule_single_action')) {
        as_schedule_single_action(time() + 15, 'omnixep_verify_single_order', array($order_id));
    }

    wp_send_json_success(array('redirect' => $order->get_checkout_order_received_url()));
}

function wc_omnixep_ajax_fetch_balance_handler()
{
    if (class_exists('WC_Gateway_Omnixep')) {
        $gateway = new WC_Gateway_Omnixep();
        $gateway->ajax_fetch_balance();
    }
    wp_die();
}

function wc_omnixep_ajax_fetch_utxos_handler()
{
    if (class_exists('WC_Gateway_Omnixep')) {
        $gateway = new WC_Gateway_Omnixep();
        $gateway->ajax_fetch_utxos();
    }
    wp_die();
}

function wc_omnixep_ajax_get_pending_debt_handler()
{
    if (class_exists('WC_Gateway_Omnixep')) {
        $gateway = new WC_Gateway_Omnixep();
        $gateway->ajax_get_pending_debt();
    }
    wp_die();
}

function wc_omnixep_ajax_settle_debt_handler()
{
    if (class_exists('WC_Gateway_Omnixep')) {
        $gateway = new WC_Gateway_Omnixep();
        $gateway->ajax_settle_debt();
    }
    wp_die();
}

function wc_omnixep_ajax_broadcast_tx_handler()
{
    if (class_exists('WC_Gateway_Omnixep')) {
        $gateway = new WC_Gateway_Omnixep();
        $gateway->ajax_broadcast_tx();
    }
    wp_die();
}

function wc_omnixep_ajax_api_proxy_handler()
{
    if (class_exists('WC_Gateway_Omnixep')) {
        $gateway = new WC_Gateway_Omnixep();
        $gateway->ajax_api_proxy();
    }
    wp_die();
}

/**
 * Add OmniXEP Payment Settings to WordPress Admin Menu
 */
function wc_omnixep_add_admin_menu()
{
    add_menu_page(
        'OmniXEP Payment Settings',           // Page title
        'OmniXEP Payment',                    // Menu title
        'manage_woocommerce',                 // Capability required
        'omnixep-payment-settings',           // Menu slug
        'wc_omnixep_admin_page_redirect',     // Callback function
        'dashicons-money-alt',                // Icon (WordPress dashicon)
        56                                    // Position (after WooCommerce)
    );
}
add_action('admin_menu', 'wc_omnixep_add_admin_menu');

/**
 * Redirect to WooCommerce OmniXEP settings page
 */
function wc_omnixep_admin_page_redirect()
{
    $settings_url = admin_url('admin.php?page=wc-settings&tab=checkout&section=omnixep');
    wp_redirect($settings_url);
    exit;
}

/**
 * Also handle direct menu click redirect (for cases where callback doesn't trigger)
 */
function wc_omnixep_admin_menu_redirect()
{
    if (isset($_GET['page']) && $_GET['page'] === 'omnixep-payment-settings') {
        wp_redirect(admin_url('admin.php?page=wc-settings&tab=checkout&section=omnixep'));
        exit;
    }
}
add_action('admin_init', 'wc_omnixep_admin_menu_redirect');

/**
 * Helper to fetch address balance from multiple sources
 */
function wc_omnixep_get_address_balance($address)
{
    if (empty($address))
        return 0;

    // Check cache first
    $cache_key = 'omnixep_addr_balance_' . md5($address);
    $cached = get_transient($cache_key);
    if ($cached !== false)
        return floatval($cached);

    $balance = 0;
    $found = false;

    // 1. Try OmniXEP API (Property ID 0)
    $api_url = "https://api.omnixep.com/api/v2/address/{$address}/balances?_t=" . time();
    $response = wp_remote_get($api_url, array('timeout' => 3));

    if (!is_wp_error($response)) {
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        if ($data && isset($data['data']['balances']) && is_array($data['data']['balances'])) {
            foreach ($data['data']['balances'] as $b) {
                $pid = $b['property_id'] ?? $b['propertyid'] ?? $b['id'] ?? null;
                if ($pid !== null && (int) $pid === 0) {
                    $raw = (float) ($b['balance'] ?? $b['total'] ?? $b['value'] ?? 0);
                    $decimals = (isset($b['decimals']) && ($b['decimals'] === true || $b['decimals'] === 'true' || (int) $b['decimals'] === 1 || (int) $b['decimals'] === 8));
                    $balance = $decimals ? ($raw / 100000000) : $raw;
                    $found = true;
                    // error_log('[OmniXEP] Balance from API (0): ' . $balance);
                    break;
                }
            }
        }
    } else {
        error_log('[OmniXEP] API Error (OmniXEP API): ' . $response->get_error_message());
    }

    // 2. Fallback to ElectrumX
    if (!$found) {
        $alt_url = "https://electrumx.xep.ai/api/address/{$address}/balance";
        $response = wp_remote_get($alt_url, array('timeout' => 3));
        if (!is_wp_error($response)) {
            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body, true);
            if ($data && (isset($data['confirmed']) || isset($data['balance']))) {
                if (isset($data['confirmed'])) {
                    $balance = (floatval($data['confirmed']) + floatval($data['unconfirmed'] ?? 0)) / 100000000;
                } else {
                    $balance = $data['balance'] > 100000 ? floatval($data['balance']) / 100000000 : floatval($data['balance']);
                }
                $found = true;
                // error_log('[OmniXEP] Balance from ElectrumX: ' . $balance);
            }
        } else {
            error_log('[OmniXEP] API Error (ElectrumX): ' . $response->get_error_message());
        }
    }

    if ($found) {
        set_transient($cache_key, $balance, 30 * MINUTE_IN_SECONDS);
        // Also update the fee wallet balance for other checks (compatibility)
        set_transient('omnixep_fee_wallet_balance_' . md5($address), $balance, 30 * MINUTE_IN_SECONDS);
        return $balance;
    } else {
        error_log('[OmniXEP] Failed to find balance for address: ' . $address);
        return false;
    }
}

/**
 * Check fee wallet balance and show warning if low
 */
function wc_omnixep_check_commission_wallet_balance()
{
    // Only run on admin pages
    if (!is_admin() || !current_user_can('manage_woocommerce')) {
        return;
    }

    // Get the fee wallet address from settings
    $settings = get_option('woocommerce_omnixep_settings', array());
    $fee_wallet_address = isset($settings['fee_wallet_address']) ? trim($settings['fee_wallet_address']) : (isset($settings['merchant_address']) ? trim($settings['merchant_address']) : '');

    if (empty($fee_wallet_address)) {
        return;
    }

    // Auto-clear cache when on the OmniXEP settings page to show live balance
    $is_settings_page = (isset($_GET['page']) && $_GET['page'] === 'wc-settings' && isset($_GET['section']) && $_GET['section'] === 'omnixep');
    if ($is_settings_page || isset($_GET['omnixep_clear_cache'])) {
        delete_transient('omnixep_addr_balance_' . md5($fee_wallet_address));
        delete_transient('omnixep_fee_wallet_balance_' . md5($fee_wallet_address));
    }

    $balance = wc_omnixep_get_address_balance($fee_wallet_address);

    // Only set warning if we actually got a balance and it's less than 10000
    if ($balance !== false && $balance < 10000) {
        $GLOBALS['omnixep_low_balance_warning'] = array(
            'balance' => $balance,
            'address' => $fee_wallet_address
        );
    } elseif ($balance !== false) {
        unset($GLOBALS['omnixep_low_balance_warning']);
    }
}
add_action('admin_init', 'wc_omnixep_check_commission_wallet_balance');

/**
 * Display low balance admin notice
 */
function wc_omnixep_low_balance_admin_notice()
{
    // Check if we should force show (useful for debugging)
    $force = isset($_GET['omnixep_debug_notice']);

    if (empty($GLOBALS['omnixep_low_balance_warning']) && !$force) {
        wc_omnixep_check_commission_wallet_balance();
    }

    if (empty($GLOBALS['omnixep_low_balance_warning']) && !$force) {
        return;
    }

    $warning = $GLOBALS['omnixep_low_balance_warning'] ?? [
        'balance' => 0,
        'address' => 'Debug Mode Active'
    ];

    $balance = number_format($warning['balance'], 2);
    $address = $warning['address'];
    $short_address = substr($address, 0, 10) . '...' . substr($address, -8);

    ?>
    <div class="notice notice-warning is-dismissible omnixep-low-balance-notice"
        style="border-left-color: #ff6b35; background: linear-gradient(135deg, #fff8f0 0%, #fff3e6 100%);">
        <div style="display: flex; align-items: center; padding: 10px 0;">
            <span style="font-size: 32px; margin-right: 15px;">⚠️</span>
            <div>
                <p style="margin: 0 0 5px 0; font-size: 14px; font-weight: bold; color: #d35400;">
                    🔔 OmniXEP Fee Wallet Low Balance Warning!
                </p>
                <p style="margin: 0; color: #7f5000;">
                    Your fee wallet (<code
                        style="background: #fff; padding: 2px 6px; border-radius: 3px;"><?php echo esc_html($short_address); ?></code>)
                    currently has <strong style="color: #c0392b;"><?php echo esc_html($balance); ?> XEP</strong>.
                </p>
                <p style="margin: 5px 0 0 0; color: #7f5000;">
                    ℹ️ <strong>Recommendation:</strong> To ensure uninterrupted payment processing, your OmniXEP module
                    fee wallet should have at least <strong style="color: #27ae60;">10,000 XEP</strong>.
                </p>
            </div>
        </div>
    </div>
    <style>
        .omnixep-low-balance-notice .notice-dismiss:before {
            color: #d35400;
        }

        .omnixep-low-balance-notice .notice-dismiss:hover:before {
            color: #c0392b;
        }
    </style>
    <?php
}
add_action('admin_notices', 'wc_omnixep_low_balance_admin_notice');

/**
 * Check if OmniXEP payment module is properly configured for frontend
 * Returns array with 'configured' boolean and 'message' if not configured
 * 
 * PERFORMANCE: This function is called on every cart/checkout page load.
 * It ONLY checks cached balance - never makes external API calls on frontend.
 */
function wc_omnixep_check_module_configuration()
{
    // Static cache to prevent multiple checks in same request
    static $cached_result = null;
    if ($cached_result !== null) {
        return $cached_result;
    }

    $settings = get_option('woocommerce_omnixep_settings', array());

    // Check if gateway is enabled
    $enabled = isset($settings['enabled']) ? $settings['enabled'] : 'no';
    if ($enabled !== 'yes') {
        $cached_result = array('configured' => true, 'message' => '');
        return $cached_result;
    }

    // Get wallet addresses
    $fee_wallet_address = isset($settings['fee_wallet_address']) ? trim($settings['fee_wallet_address']) : '';
    $merchant_address = isset($settings['merchant_address']) ? trim($settings['merchant_address']) : '';

    // Check if fee wallet or merchant address is configured
    $wallet_address = !empty($fee_wallet_address) ? $fee_wallet_address : $merchant_address;

    if (empty($wallet_address)) {
        $cached_result = array(
            'configured' => false,
            'message' => 'OmniXEP payment module is not fully configured. Please contact the store administrator. Payment wallet address is not set.'
        );
        return $cached_result;
    }

    // PERFORMANCE FIX: Only check CACHED balance on frontend - NEVER make API calls here
    // The balance is refreshed in admin_init hook (wc_omnixep_check_commission_wallet_balance)
    $cache_key = 'omnixep_addr_balance_' . md5($wallet_address);
    $cached_balance = get_transient($cache_key);

    // If no cached balance exists, assume configured (admin will refresh it)
    // This prevents API calls from blocking page loads
    if ($cached_balance === false) {
        $cached_result = array('configured' => true, 'message' => '');
        return $cached_result;
    }

    $balance = floatval($cached_balance);

    if ($balance < 2000) {
        $cached_result = array(
            'configured' => false,
            'message' => 'OmniXEP payment module is currently unavailable due to insufficient balance. Please contact the store administrator. (Transaction wallet requires at least 2,000 XEP).'
        );
        return $cached_result;
    }

    $cached_result = array('configured' => true, 'message' => '');
    return $cached_result;
}

/**
 * Display frontend warning if OmniXEP module is not properly configured
 * Shows on cart and checkout pages
 */
function wc_omnixep_frontend_configuration_warning()
{
    // Only show on cart and checkout pages
    if (!is_cart() && !is_checkout()) {
        return;
    }

    $config_check = wc_omnixep_check_module_configuration();

    if ($config_check['configured']) {
        return;
    }

    ?>
    <div id="omnixep-extension-warning" class="woocommerce-notice woocommerce-notice--error woocommerce-error" role="alert"
        style="display: none; background: linear-gradient(135deg, #fff5f5 0%, #fed7d7 100%); border: 1px solid #fc8181; border-left: 4px solid #e53e3e; border-radius: 8px; padding: 16px 20px; margin: 20px 0; z-index: 9999; position: relative;">
        <div style="display: flex; align-items: flex-start; gap: 12px;">
            <span style="font-size: 24px; line-height: 1;">⚠️</span>
            <div>
                <strong style="color: #c53030; font-size: 15px; display: block; margin-bottom: 6px;">WARNING: OmniXEP Wallet
                    Not Found</strong>
                <p style="margin: 0; color: #742a2a; font-size: 14px; line-height: 1.5;">
                    The OmniXEP Wallet browser extension is required to complete payment. If you are using
                    <strong>Incognito/Private mode</strong>, you must enable "Allow in incognito" in the extension settings
                    or use a normal window.
                </p>
            </div>
        </div>
    </div>

    <script>     (function () {
            function checkOmnixepExtension() {
                const warning = document.getElementById('omnixep-extension-warning'); if (!warning) return;
                const isExtensionPresent = (typeof window.omnixep !== 'undefined' && window.omnixep !== null);
                if (!isExtensionPresent) { warning.style.display = 'block'; } else { warning.style.display = 'none'; }
            }
            checkOmnixepExtension(); setTimeout(checkOmnixepExtension, 1000); setTimeout(checkOmnixepExtension, 3000); setTimeout(checkOmnixepExtension, 5000); window.addEventListener('load', checkOmnixepExtension);
        })();
    </script>

    <?php if (!$config_check['configured']): ?>
        <div class="woocommerce-notice woocommerce-notice--error woocommerce-error omnixep-config-warning" role="alert" style="
        background: linear-gradient(135deg, #fff5f5 0%, #fed7d7 100%);
        border: 1px solid #fc8181;
        border-left: 4px solid #e53e3e;
        border-radius: 8px;
        padding: 16px 20px;
        margin: 20px 0;
        box-shadow: 0 2px 8px rgba(229, 62, 62, 0.15);
    ">
            <div style="display: flex; align-items: flex-start; gap: 12px;">
                <span style="font-size: 24px; line-height: 1;">⚠️</span>
                <div>
                    <strong style="color: #c53030; font-size: 15px; display: block; margin-bottom: 6px;">
                        Payment Module Configuration Issue
                    </strong>
                    <p style="margin: 0; color: #742a2a; font-size: 14px; line-height: 1.5;">
                        <?php echo esc_html($config_check['message']); ?>
                    </p>
                    <p style="margin: 8px 0 0 0; color: #9b2c2c; font-size: 13px;">
                        <em>Cryptocurrency payment option may not be available until this is resolved.</em>
                    </p>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php
}
add_action('woocommerce_before_cart', 'wc_omnixep_frontend_configuration_warning');
add_action('woocommerce_before_checkout_form', 'wc_omnixep_frontend_configuration_warning');

/**
 * Register Custom Order Status: Crypto Payment
 */
function wc_omnixep_register_crypto_status()
{
    // Confirmed crypto payment
    register_post_status('wc-crypto', array(
        'label' => 'Crypto Payment',
        'public' => true,
        'exclude_from_search' => false,
        'show_in_admin_all_list' => true,
        'show_in_admin_status_list' => true,
        'label_count' => _n_noop('Crypto Payment <span class="count">(%s)</span>', 'Crypto Payment <span class="count">(%s)</span>')
    ));

    // Pending crypto payment (in mempool, awaiting confirmation)
    register_post_status('wc-pending-crypto', array(
        'label' => 'Pending Crypto Payment',
        'public' => true,
        'exclude_from_search' => false,
        'show_in_admin_all_list' => true,
        'show_in_admin_status_list' => true,
        'label_count' => _n_noop('Pending Crypto Payment <span class="count">(%s)</span>', 'Pending Crypto Payment <span class="count">(%s)</span>')
    ));
}
add_action('init', 'wc_omnixep_register_crypto_status');

/**
 * Add Custom Status to WC Order Statuses
 */
function wc_omnixep_add_crypto_to_order_statuses($order_statuses)
{
    $new_order_statuses = array();
    foreach ($order_statuses as $key => $status) {
        $new_order_statuses[$key] = $status;
        if ('wc-on-hold' === $key) { // Add after on-hold
            $new_order_statuses['wc-pending-crypto'] = 'Pending Crypto Payment';
            $new_order_statuses['wc-crypto'] = 'Crypto Payment';
        }
    }
    return $new_order_statuses;
}
add_filter('wc_order_statuses', 'wc_omnixep_add_crypto_to_order_statuses');

/**
 * Allow payment for pending-crypto orders (needed for mobile deep link flow)
 */
function wc_omnixep_valid_order_statuses_for_payment($statuses, $order)
{
    $statuses[] = 'pending-crypto';
    return $statuses;
}
add_filter('woocommerce_valid_order_statuses_for_payment', 'wc_omnixep_valid_order_statuses_for_payment', 10, 2);

/**
 * Allow payment_complete() to work from pending-crypto status
 * WITHOUT THIS, payment_complete() silently fails because WooCommerce
 * only allows it from 'pending', 'on-hold', 'failed' by default.
 */
function wc_omnixep_valid_order_statuses_for_payment_complete($statuses, $order)
{
    $statuses[] = 'pending-crypto';
    return $statuses;
}
add_filter('woocommerce_valid_order_statuses_for_payment_complete', 'wc_omnixep_valid_order_statuses_for_payment_complete', 10, 2);

/**
 * Schedule recurring Action Scheduler job for checking pending confirmations
 */
function wc_omnixep_schedule_confirmation_check()
{
    if (!function_exists('as_next_scheduled_action')) {
        return; // Action Scheduler not available
    }

    // Schedule a recurring action to check pending confirmations (Failsafe)
    if (false === as_next_scheduled_action('omnixep_check_pending_confirmations')) {
        as_schedule_recurring_action(time(), 60, 'omnixep_check_pending_confirmations'); // Run every 1 minute as failsafe
    }
}
add_action('init', 'wc_omnixep_schedule_confirmation_check');

// MANUAL CHECK BUTTON & HANDLER
add_action('admin_init', function () {
    if (isset($_GET['omnixep_check_now']) && $_GET['omnixep_check_now'] == '1' && current_user_can('manage_woocommerce')) {

        if (!isset($_GET['_wpnonce']) || !wp_verify_nonce($_GET['_wpnonce'], 'omnixep_manual_check')) {
            wp_die('Security check failed');
        }

        $debug_log = [];
        wc_omnixep_process_pending_confirmations($debug_log);

        set_transient('omnixep_manual_check_result', $debug_log, 60);

        wp_redirect(remove_query_arg(array('omnixep_check_now', '_wpnonce')));
        exit;
    }
});

// 2. Show Button & Results
add_action('admin_notices', function () {
    $screen = get_current_screen();

    $is_order_page = false;
    if ($screen && ($screen->id === 'edit-shop_order' || $screen->id === 'woocommerce_page_wc-orders')) {
        $is_order_page = true;
    }

    if ($is_order_page) {
        $pending_count = 0;
        $temp_orders = wc_get_orders(['status' => ['wc-pending-crypto', 'pending-crypto'], 'limit' => -1, 'return' => 'ids']);
        $pending_count = count($temp_orders);

        if ($pending_count > 0) {
            $url = add_query_arg(array(
                'omnixep_check_now' => '1',
                '_wpnonce' => wp_create_nonce('omnixep_manual_check')
            ));
            echo '<div class="notice notice-warning">';
            echo '<p>';
            echo '<strong>OmniXEP:</strong> Found ' . esc_html($pending_count) . ' pending crypto payment(s). ';
            echo '<a href="' . esc_url($url) . '" class="button button-primary" style="margin-left: 10px;">Check Status Now</a>';
            echo '</p>';
            echo '</div>';
        }
    }

    $results = get_transient('omnixep_manual_check_result');
    if ($results) {
        delete_transient('omnixep_manual_check_result');

        echo '<div class="notice notice-info is-dismissible" style="border-left-color: #2ecc71; border-left-width: 5px;">';
        echo '<p><strong>OmniXEP MANUAL CHECK - Results:</strong></p>';
        echo '<ul style="max-height: 250px; overflow-y: auto;">';
        if (empty($results)) {
            echo '<li>No pending crypto orders found in "wc-pending-crypto" status.</li>';
        } else {
            foreach ($results as $log) {
                echo '<li>' . esc_html($log) . '</li>';
            }
        }
        echo '</ul>';
        echo '</div>';
    }
});

// Hook for single order verification (Smart Polling)
add_action('omnixep_verify_single_order', 'wc_omnixep_verify_single_order', 10, 1);

/**
 * Smart Polling: Verify a SINGLE order
 * Checks confirmation, updates status, or reschedules itself with backoff.
 */
function wc_omnixep_verify_single_order($order_id)
{
    $lock_key = 'omnixep_verify_lock_' . $order_id;

    if (get_transient($lock_key)) {
        error_log('OmniXEP Smart Polling: Order #' . $order_id . ' is already being verified. Skipping.');
        return;
    }

    set_transient($lock_key, 1, 30);

    $order = wc_get_order($order_id);
    if (!$order) {
        delete_transient($lock_key);
        return;
    }

    if (!in_array($order->get_status(), array('pending-crypto', 'wc-pending-crypto'))) {
        delete_transient($lock_key);
        return;
    }

    $txid = $order->get_meta('_omnixep_txid');
    if (!$txid) {
        delete_transient($lock_key);
        return;
    }

    $order_created = $order->get_date_created()->getTimestamp();
    if (time() - $order_created > 86400) {
        $order->update_status('failed', 'Crypto payment not confirmed within 24 hours.');
        delete_transient($lock_key);
        return;
    }

    if (!preg_match('/^[a-fA-F0-9]{64}$/', $txid)) {
        error_log('OmniXEP Smart Polling: Invalid TXID format for #' . $order_id);
        delete_transient($lock_key);
        return;
    }

    // Use the robust gateway verification (checks recipient, amount, token PID, and confirmations)
    if (class_exists('WC_Gateway_Omnixep')) {
        $gateway = new WC_Gateway_Omnixep();
        $verified = $gateway->verify_transaction_on_chain($txid, $order, true);

        if ($verified) {
            // Respect configured status
            $target_status = $gateway->get_option('order_status', 'processing');
            if (strpos($target_status, 'wc-') === 0) {
                $target_status = substr($target_status, 3);
            }
            if (empty($target_status) || $target_status === 'pending-crypto' || $target_status === 'pending') {
                $target_status = 'processing';
            }

            // Direct status update (payment_complete has whitelist issues with custom statuses)
            $order->set_transaction_id(esc_html($txid));
            $order->update_status($target_status, 'Crypto payment confirmed via background verification. TXID: ' . esc_html($txid));
            $order->save();

            wc_reduce_stock_levels($order_id);
            do_action('woocommerce_payment_complete', $order_id);

            error_log('OmniXEP Smart Polling: Order #' . $order_id . ' completed. Status: ' . $target_status);

            delete_transient($lock_key);
            return;
        }
    }

    $current_interval = (int) $order->get_meta('_omnixep_next_check_interval');

    if ($current_interval <= 0)
        $current_interval = 120;

    $next_interval = floor($current_interval * 1.5);
    if ($next_interval > 3600)
        $next_interval = 3600;

    $order->update_meta_data('_omnixep_next_check_interval', $next_interval);
    $order->save();

    as_schedule_single_action(time() + $current_interval, 'omnixep_verify_single_order', array($order_id));
    delete_transient($lock_key);
}


/**
 * Process pending crypto payments - check for blockchain confirmations
 * @param array $debug_output Reference to array to store debug strings
 */
function wc_omnixep_process_pending_confirmations(&$debug_output = null)
{
    if ($debug_output === null)
        $debug_output = []; // Initialize if not provided

    // Verify function is running
    error_log('OmniXEP Cron: Starting execution at ' . date('Y-m-d H:i:s'));
    $debug_output[] = 'Cron started at ' . date('H:i:s');

    // Query all orders with pending-crypto status
    $args = array(
        'status' => array('wc-pending-crypto', 'pending-crypto'), // Handle both slug formats
        'limit' => 50, // Process up to 50 orders per run
        'return' => 'ids'
    );

    $order_ids = wc_get_orders($args);
    error_log('OmniXEP Cron: Found ' . count($order_ids) . ' pending orders.');
    $debug_output[] = 'Found ' . count($order_ids) . ' matching orders.';

    foreach ($order_ids as $order_id) {
        $order = wc_get_order($order_id);
        if (!$order)
            continue;

        $txid = $order->get_meta('_omnixep_txid');
        error_log('OmniXEP Cron: Checking Order #' . $order_id . ' (TXID: ' . ($txid ? $txid : 'NONE') . ')');

        if (!$txid) {
            // Don't fail mobile pending orders that are waiting for wallet callback
            $mobile_pending = $order->get_meta('_omnixep_mobile_pending');
            if ($mobile_pending === '1') {
                $debug_output[] = 'Order #' . $order_id . ' skipped (Mobile payment pending)';
                continue;
            }
            $order->update_status('failed', 'No transaction ID found for pending crypto payment.');
            error_log('OmniXEP Cron: Order #' . $order_id . ' failed - No TXID');
            $debug_output[] = 'Order #' . $order_id . ' skipped (No TXID)';
            continue;
        }

        // Check if order is too old (24 hours timeout)
        $order_created = $order->get_date_created()->getTimestamp();
        if (time() - $order_created > 86400) {
            $order->update_status('failed', 'Crypto payment not confirmed within 24 hours.');
            error_log('OmniXEP Cron: Order #' . $order_id . ' failed - Timeout');
            $debug_output[] = 'Order #' . $order_id . ' Failed (Timeout)';
            continue;
        }

        // Try to verify with ALL security checks (Recipient, Amount, Token, and Commission if applicable)
        $gateway = new WC_Gateway_Omnixep();
        $verified = $gateway->verify_transaction_on_chain($txid, $order, true);

        if (!$verified) {
            $debug_output[] = 'Order #' . $order_id . ': Verification failed (Recipient/Amount mismatch or unconfirmed)';
            continue;
        }

        // SUCCESS! If $verified is true, verify_transaction_on_chain already confirmed everything
        $debug_output[] = 'Order #' . $order_id . ': SUCCESS! Verification passed.';

        $target_status = $gateway->get_option('order_status', 'processing');
        if (strpos($target_status, 'wc-') === 0) {
            $target_status = substr($target_status, 3);
        }
        // pending-crypto is the WAITING status, not a valid completion status
        if (empty($target_status) || $target_status === 'pending-crypto' || $target_status === 'pending') {
            $target_status = 'processing';
        }

        $old_status = $order->get_status();
        $debug_output[] = 'Order #' . $order_id . ': Old status=' . $old_status . ', Target=' . $target_status;

        // Use direct update_status instead of payment_complete (which has whitelist issues)
        $order->set_transaction_id(esc_html($txid));
        $order->update_status($target_status, 'Crypto payment confirmed via blockchain verification. TXID: ' . esc_html($txid));
        $order->save();

        $new_status = $order->get_status();
        $debug_output[] = 'Order #' . $order_id . ': New status=' . $new_status;
        error_log('OmniXEP Cron: Order #' . $order_id . ' status changed from ' . $old_status . ' to ' . $new_status);

        // Reduce stock and clear carts
        wc_reduce_stock_levels($order_id);
        do_action('woocommerce_payment_complete', $order_id);
    }
}
add_action('omnixep_check_pending_confirmations', 'wc_omnixep_process_pending_confirmations');


/**
 * MEXC Price Fetcher
 */
function wc_omnixep_fetch_mexc_price($symbol)
{
    if (empty($symbol))
        return 0;

    $cache_key = 'omnixep_mexc_' . strtoupper($symbol);
    $cached = get_transient($cache_key);
    if ($cached !== false)
        return (float) $cached;

    $response = wp_remote_get("https://api.mexc.com/api/v3/ticker/price?symbol=" . urlencode(strtoupper($symbol)), array(
        'timeout' => 5,
        'user-agent' => 'OmniXEP-WooCommerce/1.0'
    ));

    if (is_wp_error($response))
        return 0;

    $data = json_decode(wp_remote_retrieve_body($response), true);
    $price = isset($data['price']) ? (float) $data['price'] : 0;

    if ($price > 0) {
        set_transient($cache_key, $price, 300);
    }

    return $price;
}

/**
 * Dex-Trade Price Fetcher
 */
function wc_omnixep_fetch_dextrade_price($pair)
{
    if (empty($pair))
        return 0;

    $cache_key = 'omnixep_dextrade_' . strtoupper($pair);
    $cached = get_transient($cache_key);
    if ($cached !== false)
        return (float) $cached;

    $response = wp_remote_get("https://api.dex-trade.com/v1/public/ticker?pair=" . urlencode(strtoupper($pair)), array(
        'timeout' => 5,
        'user-agent' => 'OmniXEP-WooCommerce/1.0'
    ));

    if (is_wp_error($response))
        return 0;

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    // Dex-Trade API response structure: { "status": true, "data": { "last": "0.000123", ... } }
    if (!isset($data['status']) || $data['status'] !== true || !isset($data['data']['last'])) {
        return 0;
    }

    $price = (float) $data['data']['last'];

    if ($price > 0) {
        set_transient($cache_key, $price, 300);
    }

    return $price;
}


/**
 * Custom function to fetch prices with Caching and Source support
 */
function wc_omnixep_get_prices($cg_ids_str, $tokens = [])
{
    $prices = [];
    $cg_ids = [];

    // 1. Session-based Lock Check (Per-user price persistence)
    $last_fetch = 0;
    $session_prices = [];
    if (!is_admin() && function_exists('WC') && WC()->session) {
        $last_fetch = (int) WC()->session->get('omnixep_last_fetch_time');
        $session_prices = (array) WC()->session->get('omnixep_price_cache');

        // If we have a valid cache within the 30s window
        if ($last_fetch && (time() - $last_fetch < 30) && !empty($session_prices)) {
            // Check if all requested tokens are present
            $all_present = true;
            foreach ($tokens as $token) {
                $p_id = isset($token['price_id']) ? $token['price_id'] : (isset($token['cg_id']) ? $token['cg_id'] : '');
                if ($p_id && !isset($session_prices[$p_id])) {
                    $all_present = false;
                    break;
                }
            }
            if ($all_present) {
                return $session_prices;
            }
        }
    }

    // 2. Fetch logic (if session empty, expired, or partial)
    if (!empty($cg_ids_str)) {
        $cg_ids = explode(',', $cg_ids_str);
    }

    foreach ($tokens as $token) {
        $source = isset($token['source']) ? $token['source'] : 'coingecko';
        $p_id = isset($token['price_id']) ? $token['price_id'] : (isset($token['cg_id']) ? $token['cg_id'] : '');

        if ($source === 'mexc') {
            $price = wc_omnixep_fetch_mexc_price($p_id);
            if ($price > 0)
                $prices[$p_id]['usd'] = $price;
        } else if ($source === 'dextrade') {
            $price = wc_omnixep_fetch_dextrade_price($p_id);
            if ($price > 0)
                $prices[$p_id]['usd'] = $price;
        } else if ($source === 'coingecko') {
            if (!empty($p_id) && !in_array($p_id, $cg_ids)) {
                $cg_ids[] = $p_id;
            }
        }
    }

    if (!empty($cg_ids)) {
        $cg_ids_query = implode(',', array_filter($cg_ids));
        $cache_key = 'omnixep_gecko_' . md5($cg_ids_query);
        $cached_gecko = get_transient($cache_key);

        if ($cached_gecko !== false) {
            $prices = array_merge($prices, $cached_gecko);
        } else {
            $url = "https://api.coingecko.com/api/v3/simple/price?ids=" . urlencode($cg_ids_query) . "&vs_currencies=usd";
            $settings = get_option('woocommerce_omnixep_settings');
            $cg_api_key = isset($settings['coingecko_api_key']) ? $settings['coingecko_api_key'] : '';

            $args = array('timeout' => 10, 'user-agent' => 'OmniXEP-WooCommerce/1.0');
            if (!empty($cg_api_key)) {
                $url = "https://pro-api.coingecko.com/api/v3/simple/price?ids=" . urlencode($cg_ids_query) . "&vs_currencies=usd";
                $args['headers'] = array('x-cg-pro-api-key' => $cg_api_key);
            }

            $response = wp_remote_get($url, $args);
            if (!is_wp_error($response)) {
                $data = json_decode(wp_remote_retrieve_body($response), true);
                if ($data) {
                    $prices = array_merge($prices, $data);
                    set_transient($cache_key, $data, 30);
                }
            } else {
                error_log('OmniXEP Price Fetch Error (CoinGecko): ' . $response->get_error_message());
            }
        }
    }

    // 3. Final Storage & Return
    $final_prices = array_merge($session_prices, $prices);
    if (!is_admin() && function_exists('WC') && WC()->session) {
        WC()->session->set('omnixep_price_cache', $final_prices);
        if (!$last_fetch || (time() - $last_fetch >= 30)) {
            WC()->session->set('omnixep_last_fetch_time', time());
        }
    }

    return $final_prices;
}

/**
 * Filter to fix Mixed Content for Favicon and other internal assets
 * Aggressive fix: Hook into clean_url to catch URLs passed via esc_url()
 */
function wc_omnixep_force_ssl_assets($url)
{
    if (is_ssl() && is_string($url) && strpos($url, 'http://') === 0) {
        $url = str_replace('http://', 'https://', $url);
    }
    return $url;
}
add_filter('get_site_icon_url', 'wc_omnixep_force_ssl_assets', 99);
add_filter('wp_get_attachment_url', 'wc_omnixep_force_ssl_assets', 99);
add_filter('theme_file_uri', 'wc_omnixep_force_ssl_assets', 99);
add_filter('clean_url', 'wc_omnixep_force_ssl_assets', 99);
add_filter('wp_calculate_image_srcset', function ($sources) {
    if (is_ssl()) {
        foreach ($sources as &$source) {
            $source['url'] = str_replace('http://', 'https://', $source['url']);
        }
    }
    return $sources;
}, 99);

/**
 * AJAX Handler for Test Price Fetch
 */
add_action('wp_ajax_omnixep_test_price', 'wc_omnixep_test_price_ajax');
function wc_omnixep_test_price_ajax()
{
    check_ajax_referer('omnixep_test_price_nonce', 'nonce');
    if (!current_user_can('manage_woocommerce'))
        wp_send_json_error('Unauthorized');

    $source = sanitize_text_field($_POST['source']);
    $price_id = sanitize_text_field($_POST['price_id']);

    if (empty($price_id))
        wp_send_json_error('Price ID is required');

    $price = 0;
    if ($source === 'mexc') {
        $price = wc_omnixep_fetch_mexc_price($price_id);
    } else if ($source === 'dextrade') {
        $price = wc_omnixep_fetch_dextrade_price($price_id);
    } else {
        // Gecko Test with global key
        $settings = get_option('woocommerce_omnixep_settings');
        $api_key = isset($settings['coingecko_api_key']) ? $settings['coingecko_api_key'] : '';

        $url = "https://api.coingecko.com/api/v3/simple/price?ids=" . urlencode($price_id) . "&vs_currencies=usd";
        $args = array('timeout' => 10);
        if (!empty($api_key)) {
            $url = "https://pro-api.coingecko.com/api/v3/simple/price?ids=" . urlencode($price_id) . "&vs_currencies=usd";
            $args['headers'] = array('x-cg-pro-api-key' => $api_key);
        }
        $response = wp_remote_get($url, $args);
        if (!is_wp_error($response)) {
            $data = json_decode(wp_remote_retrieve_body($response), true);
            if (isset($data[$price_id]['usd'])) {
                $price = $data[$price_id]['usd'];
            }
        }
    }

    if ($price > 0) {
        wp_send_json_success(['price' => $price]);
    } else {
        wp_send_json_error('Fetch failed. Check ID/Pair and Global API Key.');
    }
}

/**
 * Get live price for a specific token name (cached)
 */
function wc_omnixep_get_live_price($token_name)
{
    if (empty($token_name))
        return 0;

    $token_upper = strtoupper($token_name);

    // 1. Static cache for current request
    static $request_cache = [];
    if (isset($request_cache[$token_upper])) {
        return $request_cache[$token_upper];
    }

    $cache_key = 'omnixep_price_single_' . $token_upper;
    $cached_price = get_transient($cache_key);

    if ($cached_price !== false) {
        $request_cache[$token_upper] = (float) $cached_price;
        return $request_cache[$token_upper];
    }

    $price = 0;

    // Fetch token config from settings
    $settings = get_option('woocommerce_omnixep_settings', []);
    $token_config_str = isset($settings['token_config']) ? $settings['token_config'] : '';
    $tokens = wc_omnixep_parse_token_config($token_config_str);

    foreach ($tokens as $t) {
        if (strtoupper($t['name']) === $token_upper) {
            $source = isset($t['source']) ? $t['source'] : 'coingecko';
            $p_id = isset($t['price_id']) ? $t['price_id'] : (isset($t['cg_id']) ? $t['cg_id'] : '');

            if ($source === 'mexc') {
                $price = (float) wc_omnixep_fetch_mexc_price($p_id);
            } else if ($source === 'dextrade') {
                $price = (float) wc_omnixep_fetch_dextrade_price($p_id);
            } else {
                $prices = wc_omnixep_get_prices('', [$t]);
                $price = isset($prices[$p_id]['usd']) ? (float) $prices[$p_id]['usd'] : 0;
            }
            break;
        }
    }

    // MEMEX Fallback with caching
    if ($price <= 0 && $token_upper === 'MEMEX') {
        $memex_cache_key = 'omnixep_memex_geckoterminal';
        $cached_memex = get_transient($memex_cache_key);

        if ($cached_memex !== false) {
            $price = (float) $cached_memex;
        } else {
            $response = wp_remote_get('https://api.geckoterminal.com/api/v2/networks/omax-chain/pools/0xc84edbf1e3fef5e4583aaa0f818cdfebfcae095b', array('timeout' => 5));
            if (!is_wp_error($response)) {
                $body = json_decode(wp_remote_retrieve_body($response), true);
                if (isset($body['data']['attributes']['base_token_price_usd'])) {
                    $price = (float) $body['data']['attributes']['base_token_price_usd'];
                    set_transient($memex_cache_key, $price, 300); // 5 minute cache
                }
            }
        }
    }

    if ($price > 0) {
        set_transient($cache_key, $price, 30); // Cache for 30 seconds to match frontend timer
    }

    $request_cache[$token_upper] = $price;
    return $price;
}

/**
 * Add custom styling for Crypto Payment status in admin
 */
function wc_omnixep_admin_order_status_styles()
{
    ?>
    <style>
        /* Crypto Payment status badge - ONLY the status label, not the row */

        /* Target only the mark/span element with status */
        mark.order-status.status-crypto,
        mark.status-crypto,
        span.order-status.status-crypto,
        .column-order_status mark.status-crypto,
        .column-wc_actions mark.status-crypto,
        td.order_status mark.status-crypto {
            background: #28a745 !important;
            color: #fff !important;
            border-radius: 3px;
            padding: 2px 8px;
        }

        /* Pending Crypto Payment status badge - ORANGE */
        mark.order-status.status-pending-crypto,
        mark.status-pending-crypto,
        span.order-status.status-pending-crypto,
        .column-order_status mark.status-pending-crypto,
        .column-wc_actions mark.status-pending-crypto,
        td.order_status mark.status-pending-crypto {
            background: #ff9800 !important;
            color: #fff !important;
            border-radius: 3px;
            padding: 2px 8px;
        }

        /* HPOS tables - only status badge */
        .wc-orders-list-table .order-status.status-crypto,
        .woocommerce-page mark.status-crypto {
            background: #28a745 !important;
            color: #fff !important;
        }

        .wc-orders-list-table .order-status.status-pending-crypto,
        .woocommerce-page mark.status-pending-crypto {
            background: #ff9800 !important;
            color: #fff !important;
        }

        /* Crypto payment info below status */
        .omnixep-payment-info {
            display: block;
            font-size: 11px;
            color: #28a745;
            font-weight: bold;
            margin-top: 4px;
            line-height: 1.3;
        }

        .omnixep-payment-info .token-name {
            color: #0d6efd;
            font-weight: 600;
        }

        .omnixep-payment-info .usd-value {
            color: #666;
            font-weight: normal;
        }

        /* TXID link styling */
        .omnixep-txid-link {
            color: #0073aa !important;
            text-decoration: none;
            word-break: break-all;
        }

        .omnixep-txid-link:hover {
            text-decoration: underline;
        }

        .omnixep-verified {
            color: #28a745;
            font-weight: bold;
            margin-right: 5px;
        }
    </style>
    <script>
        jQuery(document).ready(function ($) {
            // Convert OmniXEP hashes to clickable links
            function convertOmniXEPHashes() {
                // Find elements that might contain the payment text and hash
                // Targeting by text content and common WooCommerce containers
                $('body').find('.wc-order-preview-payment-method, .payment-method, .method, :contains("Pay with OmniXEP")').each(function () {
                    var el = $(this);
                    // Check if it's a text node or contains only text/br
                    if (el.children(':not(br, span.omnixep-verified, a.omnixep-txid-link)').length === 0) {
                        var html = el.html();
                        // Match hash pattern: 64 character hex string, potentially surrounded by whitespace/newlines
                        var hashPattern = /\(\s*([a-fA-F0-9]{64})\s*\)/g;
                        if (hashPattern.test(html)) {
                            var newHtml = html.replace(/\(\s*([a-fA-F0-9]{64})\s*\)/g, function (match, hash) {
                                var shortHash = hash.substring(0, 16) + '...';
                                var link = '<span class="omnixep-verified">✓</span><a href="https://electraprotocol.network/transaction/' + hash + '" target="_blank" class="omnixep-txid-link">(' + shortHash + ')</a>';
                                return link;
                            });
                            if (html !== newHtml) {
                                el.html(newHtml);
                            }
                        }
                    }
                });
            }
            // Initial run
            setTimeout(convertOmniXEPHashes, 200);
            // Higher frequency for dynamic/AJAX content
            $(document).on('wc_backbone_modal_loaded', function () {
                setTimeout(convertOmniXEPHashes, 100);
                setTimeout(convertOmniXEPHashes, 500);
                setTimeout(convertOmniXEPHashes, 1000);
            });
            $(document).ajaxComplete(function () {
                setTimeout(convertOmniXEPHashes, 200);
                setTimeout(convertOmniXEPHashes, 600);
            });
            // Loop for safety against late-loading elements
            setInterval(convertOmniXEPHashes, 2000);
        });
    </script>
    <?php
}
add_action('admin_head', 'wc_omnixep_admin_order_status_styles');

/**
 * Enhanced filter for Order Preview Modal
 */
function wc_omnixep_admin_order_preview_details($data, $order)
{
    if (!$order || !is_a($order, 'WC_Order'))
        return $data;

    if ($order->get_payment_method() === 'omnixep') {
        $txid = $order->get_meta('_omnixep_txid');
        $token_name = $order->get_meta('_omnixep_token_name');
        $amount = $order->get_meta('_omnixep_amount');

        if ($txid) {
            $explorer_url = 'https://electraprotocol.network/transaction/';
            $check_icon = '<span style="color:#28a745;">✓</span>';
            $link = '<a href="' . esc_url($explorer_url . $txid) . '" target="_blank" style="color:#0073aa;">(' . esc_html(substr($txid, 0, 16)) . '...)</a>';

            $payment_via = 'Paid via OmniXEP ' . $check_icon;
            if ($token_name && $amount) {
                $payment_via .= ' <strong>' . esc_html($token_name) . ':</strong> ' . esc_html($amount);
            }
            $payment_via .= ' ' . $link;

            $data['payment_via'] = $payment_via;
        }
    }
    return $data;
}
add_filter('woocommerce_admin_order_preview_get_order_details', 'wc_omnixep_admin_order_preview_details', 20, 2);

/**
 * Display crypto payment details after order status in admin list
 */
function wc_omnixep_display_crypto_info_in_status($column, $post_id)
{
    if ($column === 'order_status') {
        $order = wc_get_order($post_id);
        if (!$order)
            return;

        // Check if this is a crypto payment order
        if ($order->get_status() === 'crypto' || $order->get_payment_method() === 'omnixep') {
            $token_name = $order->get_meta('_omnixep_token_name');
            $amount = $order->get_meta('_omnixep_amount');
            $usd_value = $order->get_meta('_omnixep_usd_value');

            if ($token_name && $amount) {
                echo '<div class="omnixep-payment-info">';
                echo '<span class="token-name">' . esc_html($token_name) . '</span>: ';
                echo esc_html($amount);

                // Show current value
                $current_price = wc_omnixep_get_live_price($token_name);
                if ($current_price > 0) {
                    $current_val = (float) $amount * $current_price;
                    echo ' <span class="usd-value">($' . esc_html(number_format($current_val, 2)) . ')</span>';
                } elseif ($usd_value) {
                    // Fallback to saved value if live fetch fails
                    echo ' <span class="usd-value">($' . esc_html(number_format((float) $usd_value, 2)) . ')</span>';
                }
                echo '</div>';
            }
        }
    }
}
add_action('manage_shop_order_posts_custom_column', 'wc_omnixep_display_crypto_info_in_status', 20, 2);

/**
 * HPOS compatibility - Display crypto payment details for new order tables
 */
function wc_omnixep_display_crypto_info_hpos($column, $order)
{
    if ($column === 'order_status') {
        if (!$order || !is_a($order, 'WC_Order'))
            return;

        // Check if this is a crypto payment order
        if ($order->get_status() === 'crypto' || $order->get_payment_method() === 'omnixep') {
            $token_name = $order->get_meta('_omnixep_token_name');
            $amount = $order->get_meta('_omnixep_amount');
            $usd_value = $order->get_meta('_omnixep_usd_value');

            if ($token_name && $amount) {
                echo '<div class="omnixep-payment-info">';
                echo '<span class="token-name">' . esc_html($token_name) . '</span>: ';
                echo esc_html($amount);

                // Show current value
                $current_price = wc_omnixep_get_live_price($token_name);
                if ($current_price > 0) {
                    $current_val = (float) $amount * $current_price;
                    echo ' <span class="usd-value">($' . esc_html(number_format($current_val, 2)) . ')</span>';
                } elseif ($usd_value) {
                    // Fallback to saved value if live fetch fails
                    echo ' <span class="usd-value">($' . esc_html(number_format((float) $usd_value, 2)) . ')</span>';
                }
                echo '</div>';
            }
        }
    }
}
add_action('manage_woocommerce_page_wc-orders_custom_column', 'wc_omnixep_display_crypto_info_hpos', 20, 2);

/**
 * Display OmniXEP payment details in order admin page (meta box)
 */
function wc_omnixep_add_payment_meta_box()
{
    $screen = function_exists('wc_get_container') ? wc_get_page_screen_id('shop-order') : 'shop_order';
    add_meta_box(
        'omnixep_payment_details',
        '💰 OmniXEP Payment Details',
        'wc_omnixep_payment_meta_box_content',
        $screen,
        'side',
        'high'
    );
    // Also add for legacy
    add_meta_box(
        'omnixep_payment_details',
        '💰 OmniXEP Payment Details',
        'wc_omnixep_payment_meta_box_content',
        'shop_order',
        'side',
        'high'
    );
}
add_action('add_meta_boxes', 'wc_omnixep_add_payment_meta_box');

/**
 * Payment meta box content
 */
function wc_omnixep_payment_meta_box_content($post_or_order)
{
    // HPOS compatibility
    if ($post_or_order instanceof WC_Order) {
        $order = $post_or_order;
    } else {
        $order = wc_get_order($post_or_order->ID);
    }

    if (!$order || $order->get_payment_method() !== 'omnixep') {
        echo '<p>This order was not paid with OmniXEP.</p>';
        return;
    }

    $txid = $order->get_meta('_omnixep_txid');
    $commission_txid = $order->get_meta('_omnixep_commission_txid');
    $token_name = $order->get_meta('_omnixep_token_name');
    $amount = $order->get_meta('_omnixep_amount');
    $merchant_amount = $order->get_meta('_omnixep_merchant_amount');
    $commission_amount = $order->get_meta('_omnixep_commission_amount');
    $commission_address = $order->get_meta('_omnixep_commission_address');
    $usd_value = $order->get_meta('_omnixep_usd_value');
    $explorer_url = 'https://electraprotocol.network/transaction/';

    echo '<div style="padding: 10px 0;">';

    if ($token_name && $amount) {
        echo '<p style="margin: 5px 0;"><strong>Token:</strong> ' . esc_html($token_name) . '</p>';
        echo '<p style="margin: 5px 0;"><strong>Total Amount:</strong> ' . esc_html($amount);
        if ($usd_value && floatval($usd_value) > 0) {
            echo ' <span style="color: #666;">($' . esc_html(number_format((float) $usd_value, 2)) . ')</span>';
        }
        echo '</p>';

        if ($commission_amount && floatval($commission_amount) > 0) {
            echo '<div style="background: #fff3cd; padding: 12px; border-left: 4px solid #ffc107; margin: 10px 0;">';
            echo '<p style="margin: 3px 0; font-size: 0.95em;"><strong>⚠️ Two-Step Payment:</strong></p>';
            echo '<p style="margin: 5px 0 5px 20px;"><strong>STEP 1 (First):</strong> Commission to XEP System</p>';
            echo '<p style="margin: 3px 0 3px 30px;">→ Amount: <strong>' . esc_html($commission_amount) . ' ' . esc_html($token_name) . '</strong></p>';
            echo '<p style="margin: 5px 0 5px 20px;"><strong>STEP 2 (Second):</strong> Order Payment to Merchant</p>';
            echo '<p style="margin: 3px 0 3px 30px;">→ Amount: <strong>' . esc_html($merchant_amount) . ' ' . esc_html($token_name) . '</strong></p>';
            if ($commission_address) {
                echo '<p style="margin: 8px 0 3px 0; font-size: 0.85em; color: #856404;">Commission Wallet: ' . esc_html(substr($commission_address, 0, 25)) . '...</p>';
            }
            echo '</div>';
        }
    }

    if ($commission_txid) {
        $comm_link = $explorer_url . $commission_txid;
        echo '<p style="margin: 10px 0 5px 0;"><strong>STEP 1 - Commission TX (FIRST):</strong></p>';
        echo '<div style="background: #d4edda; padding: 8px; border-radius: 4px; border-left: 3px solid #28a745; word-break: break-all; font-size: 11px;">';
        echo '<span style="color: #28a745; font-size: 16px; margin-right: 5px;">✓</span>';
        echo '<a href="' . esc_url($comm_link) . '" target="_blank" style="color: #155724;">';
        echo esc_html(substr($commission_txid, 0, 20)) . '...';
        echo '</a>';
        echo '</div>';
        echo '<p style="margin-top: 8px;"><a href="' . esc_url($comm_link) . '" target="_blank" class="button button-small">🔍 View Commission TX</a></p>';
    } elseif ($commission_amount && floatval($commission_amount) > 0) {
        echo '<p style="color: #dc3545; margin: 10px 0;"><strong>⚠️ STEP 1 - Commission TX:</strong> Not received yet (required first!)</p>';
    }

    if ($txid) {
        $tx_link = $explorer_url . $txid;
        echo '<p style="margin: 10px 0 5px 0;"><strong>STEP 2 - Order TX (SECOND):</strong></p>';
        echo '<div style="background: #d4edda; padding: 8px; border-radius: 4px; border-left: 3px solid #28a745; word-break: break-all; font-size: 11px;">';
        echo '<span style="color: #28a745; font-size: 16px; margin-right: 5px;">✓</span>';
        echo '<a href="' . esc_url($tx_link) . '" target="_blank" style="color: #155724;">';
        echo esc_html(substr($txid, 0, 20)) . '...';
        echo '</a>';
        echo '</div>';
        echo '<p style="margin-top: 8px;"><a href="' . esc_url($tx_link) . '" target="_blank" class="button button-small">🔍 View Order TX</a></p>';
    } else {
        echo '<p style="color: #dc3545; margin: 10px 0;"><strong>⚠️ STEP 2 - Order TX:</strong> Not received</p>';
    }


    echo '</div>';

    $system_fee_debt = (float) $order->get_meta('_omnixep_system_fee_debt');
    $commission_fee_debt = (float) $order->get_meta('_omnixep_commission_fee_debt');
    $total_debt = $system_fee_debt + $commission_fee_debt;
    $debt_settled = $order->get_meta('_omnixep_debt_settled');

    if ($total_debt > 0) {
        $status_color = ($debt_settled === 'yes') ? '#28a745' : '#dc3545';
        $status_text = ($debt_settled === 'yes') ? 'Paid' : 'Pending (Merchant Debt)';
        echo '<div style="margin-top: 15px; padding: 12px; background: #f8f9fa; border: 1px solid #ddd; border-radius: 6px; border-left: 4px solid ' . $status_color . ';">';
        echo '<p style="margin: 0; font-size: 0.9em; color: #555;"><strong>📡 0.8% Sales Commission:</strong></p>';
        echo '<p style="margin: 5px 0 0 0; font-weight: bold; color: ' . $status_color . ';">' . number_format($total_debt, 8, '.', '') . ' XEP (' . $status_text . ')</p>';
        echo '</div>';
    }
}

/**
 * Also display in order notes/payment method section
 */
function wc_omnixep_display_payment_details_in_order($order)
{
    if ($order->get_payment_method() !== 'omnixep')
        return;

    $txid = $order->get_meta('_omnixep_txid');
    $token_name = $order->get_meta('_omnixep_token_name');
    $amount = $order->get_meta('_omnixep_amount');
    $explorer_url = 'https://electraprotocol.network/transaction/';

    if ($txid) {
        echo '<p><strong>OmniXEP Transaction:</strong><br>';
        echo '<span style="color: #28a745;">✓</span> ';
        echo '<a href="' . esc_url($explorer_url . $txid) . '" target="_blank">';
        echo esc_html(substr($txid, 0, 30)) . '...';
        echo '</a></p>';
    }
}
add_action('woocommerce_admin_order_data_after_billing_address', 'wc_omnixep_display_payment_details_in_order');

/**
 * Filter payment method title to include clickable TXID link
 * This makes the hash in "Pay with OmniXEP (hash)" clickable
 */
function wc_omnixep_format_payment_method_title($title, $order)
{
    if (!$order || !is_a($order, 'WC_Order'))
        return $title;
    if ($order->get_payment_method() !== 'omnixep')
        return $title;

    $txid = $order->get_meta('_omnixep_txid');
    $token_name = $order->get_meta('_omnixep_token_name');
    $amount = $order->get_meta('_omnixep_amount');
    $explorer_url = 'https://electraprotocol.network/transaction/';

    // Admin check: Return plain text to avoid escaped HTML in WooCommerce admin meta boxes
    if (is_admin() && !wp_doing_ajax()) {
        $admin_title = 'Pay with OmniXEP';
        if ($txid) {
            $admin_title .= ' (' . substr($txid, 0, 10) . '...)';
        }
        return $admin_title;
    }

    // Rich version for frontend (Account page, Checkout success, etc.)
    $result = 'Pay with OmniXEP';

    if ($txid) {
        // Verify transaction exists
        $verified = wc_omnixep_verify_transaction($txid);
        $check_icon = $verified ? '<span style="color:#28a745;">✓</span>' : '<span style="color:#ffc107;">⌛</span>';
        $result .= ' ' . $check_icon;
    }

    // Add token name and amount
    if ($token_name && $amount) {
        $result .= ' <strong>' . esc_html($token_name) . ':</strong> ' . esc_html($amount);
    }

    return $result;
}
add_filter('woocommerce_order_get_payment_method_title', 'wc_omnixep_format_payment_method_title', 20, 2);

/**
 * Verify transaction on ElectraProtocol network
 */
function wc_omnixep_verify_transaction($txid)
{
    // Cache the result for 5 minutes
    $cache_key = 'omnixep_tx_' . $txid;
    $cached = get_transient($cache_key);
    if ($cached !== false) {
        return $cached === 'verified';
    }

    // Sanitize and validate TXID to prevent SSRF
    if (!preg_match('/^[a-fA-F0-9]{64}$/', $txid)) {
        return false;
    }

    // Call ElectraProtocol API to verify transaction
    $api_url = 'https://api.electraprotocol.com/api/v2/tx/' . $txid;
    $response = wp_remote_get($api_url, array('timeout' => 5));

    if (is_wp_error($response)) {
        return false;
    }

    $body = json_decode(wp_remote_retrieve_body($response), true);

    // Check if transaction exists and has confirmations
    $verified = false;
    if (isset($body['data']['confirmations']) && intval($body['data']['confirmations']) > 0) {
        $verified = true;
    } elseif (isset($body['confirmations']) && intval($body['confirmations']) > 0) {
        $verified = true;
    } elseif (isset($body['data']['txid']) || isset($body['txid'])) {
        // Transaction exists even if 0 confirmations
        $verified = true;
    }

    // Cache for 5 minutes
    set_transient($cache_key, $verified ? 'verified' : 'pending', 300);

    return $verified;
}

/**
 * Helper to parse token configuration string into array
 * Format: id,name,source,price_id,api_key,decimals
 */
function wc_omnixep_parse_token_config($config_str)
{
    if (empty($config_str)) {
        return [
            [
                'id' => '0',
                'name' => 'XEP',
                'source' => 'mexc',
                'price_id' => 'XEPUSDT',
                'decimals' => 8
            ]
        ];
    }

    $tokens = [];
    $lines = explode("\n", $config_str);

    foreach ($lines as $line) {
        $line = trim($line);
        if (empty($line))
            continue;

        $parts = explode(',', $line);
        $count = count($parts);

        // Standard 5-part: id,name,source,price_id,decimals
        if ($count === 5 && in_array(strtolower(trim($parts[2])), ['mexc', 'coingecko', 'dextrade'])) {
            $tokens[] = [
                'id' => trim($parts[0]),
                'name' => trim($parts[1]),
                'source' => strtolower(trim($parts[2])),
                'price_id' => trim($parts[3]),
                'decimals' => intval(trim($parts[4]))
            ];
        }
        // Legacy 6-part (with api_key): id,name,source,price_id,api_key,decimals
        else if ($count >= 6) {
            $tokens[] = [
                'id' => trim($parts[0]),
                'name' => trim($parts[1]),
                'source' => strtolower(trim($parts[2])),
                'price_id' => trim($parts[3]),
                'decimals' => intval(trim($parts[5]))
            ];
        }
        // Legacy 4-part: id,name,cg_id,decimals
        else if ($count === 4) {
            $tokens[] = [
                'id' => trim($parts[0]),
                'name' => trim($parts[1]),
                'source' => 'coingecko',
                'price_id' => trim($parts[2]),
                'decimals' => intval(trim($parts[3]))
            ];
        }
        // Legacy 3-part: id,name,cg_id
        else if ($count === 3) {
            $tokens[] = [
                'id' => trim($parts[0]),
                'name' => trim($parts[1]),
                'source' => 'coingecko',
                'price_id' => trim($parts[2]),
                'decimals' => 8
            ];
        }
    }

    if (empty($tokens)) {
        return [
            [
                'id' => '0',
                'name' => 'XEP',
                'source' => 'coingecko',
                'price_id' => 'electra-protocol',
                'api_key' => '',
                'decimals' => 8
            ]
        ];
    }

    return $tokens;
}

/**
 * Render custom 'token_table' field in WooCommerce settings
 */
function wc_omnixep_render_token_table_field($value)
{
    $field_id = $value['id'];
    $field_value = get_option($field_id, $value['default']);

    // Use the robust parser
    $tokens = wc_omnixep_parse_token_config($field_value);

    // If empty, add a default row for XEP
    if (empty($tokens)) {
        $tokens[] = ['id' => '0', 'name' => 'XEP', 'cg_id' => 'electra-protocol', 'decimals' => '8', 'mexc_symbol' => 'XEPUSDT'];
    }

    ?>
    <tr valign="top">
        <th scope="row" class="titledesc">
            <label for="<?php echo esc_attr($field_id); ?>"><?php echo esc_html($value['title']); ?></label>
            <?php echo isset($value['description']) ? wc_help_tip($value['description']) : ''; ?>
        </th>
        <td class="forminp">
            <style>
                .omnixep-token-table {
                    width: 100%;
                    border-collapse: collapse;
                    margin-bottom: 10px;
                    border: 1px solid #ccd0d4;
                    max-width: 800px;
                }

                .omnixep-token-table th,
                .omnixep-token-table td {
                    padding: 10px;
                    border: 1px solid #ccd0d4;
                    text-align: left;
                }

                .omnixep-token-table th {
                    background: #f8f9fa;
                    font-weight: 600;
                }

                .omnixep-token-table input {
                    width: 100%;
                    box-sizing: border-box;
                    padding: 5px;
                    border: 1px solid #ddd;
                }

                .omnixep-remove-token {
                    color: #d63638;
                    cursor: pointer;
                    font-size: 20px;
                    line-height: 1;
                    font-weight: bold;
                }

                .omnixep-remove-token:hover {
                    color: #b32d2e;
                }

                #omnixep-add-token {
                    margin-top: 5px;
                }
            </style>

            <table class="omnixep-token-table" id="omnixep-token-config-table">
                <thead>
                    <tr>
                        <th style="width: 80px;">Token ID</th>
                        <th>Token Name</th>
                        <th>CoinGecko ID</th>
                        <th style="width: 80px;">Decimals</th>
                        <th>Price Source (Ex: BINANCE:SYMBOL)</th>
                        <th style="width: 40px;"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($tokens as $token): ?>
                        <tr class="token-row">
                            <td><input type="text" class="token-id" value="<?php echo esc_attr($token['id']); ?>"
                                    placeholder="e.g. 0"></td>
                            <td><input type="text" class="token-name" value="<?php echo esc_attr($token['name']); ?>"
                                    placeholder="e.g. XEP"></td>
                            <td><input type="text" class="token-cgid"
                                    value="<?php echo esc_attr(isset($token['price_id']) ? $token['price_id'] : (isset($token['cg_id']) ? $token['cg_id'] : '')); ?>"
                                    placeholder="e.g. electra-protocol"></td>
                            <td><input type="number" class="token-decimals" value="<?php echo esc_attr($token['decimals']); ?>"
                                    placeholder="8"></td>
                            <td><input type="text" class="token-mexc"
                                    value="<?php echo esc_attr(isset($token['mexc_symbol']) ? $token['mexc_symbol'] : ''); ?>"
                                    placeholder="Ex: BINANCE:XEPUSDT or MEXC:XEPUSDT"></td>
                            <td><span class="omnixep-remove-token" title="Remove">&times;</span></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <button type="button" class="button" id="omnixep-add-token">+ Add New Token</button>
            <p class="description"><?php echo isset($value['description']) ? esc_html($value['description']) : ''; ?></p>

            <input type="hidden" name="<?php echo esc_attr($field_id); ?>" id="<?php echo esc_attr($field_id); ?>"
                value="<?php echo esc_attr($field_value); ?>">

            <script>
                jQuery(document).ready(function ($) {
                    var $table = $('#omnixep-token-config-table tbody');
                    var $hiddenInput = $('#<?php echo esc_js($field_id); ?>');

                    function updateHiddenInput() {
                        var rows = [];
                        $table.find('.token-row').each(function () {
                            var id = $(this).find('.token-id').val().trim();
                            var name = $(this).find('.token-name').val().trim();
                            var cgid = $(this).find('.token-cgid').val().trim();
                            var decimals = $(this).find('.token-decimals').val().trim();
                            var mexc = $(this).find('.token-mexc').val().trim();
                            if (id !== '' && name !== '') {
                                rows.push(id + ',' + name + ',' + cgid + ',' + (decimals !== '' ? decimals : '8') + ',' + mexc);
                            }
                        });
                        $hiddenInput.val(rows.join('\n'));
                    }

                    $('#omnixep-add-token').on('click', function () {
                        var $newRow = $('<tr class="token-row">' +
                            '<td><input type="text" class="token-id" placeholder="ID"></td>' +
                            '<td><input type="text" class="token-name" placeholder="Name"></td>' +
                            '<td><input type="text" class="token-cgid" placeholder="CoinGecko ID"></td>' +
                            '<td><input type="number" class="token-decimals" value="8" placeholder="8"></td>' +
                            '<td><input type="text" class="token-mexc" placeholder="Ex: BINANCE:XEPUSDT"></td>' +
                            '<td><span class="omnixep-remove-token" title="Remove">&times;</span></td>' +
                            '</tr>');
                        $table.append($newRow);
                        updateHiddenInput();
                    });

                    $(document).on('click', '.omnixep-remove-token', function () {
                        if ($table.find('.token-row').length > 1) {
                            $(this).closest('tr').remove();
                            updateHiddenInput();
                        } else {
                            alert('At least one token is required.');
                        }
                    });

                    $(document).on('change keyup', '#omnixep-token-config-table input', function () {
                        updateHiddenInput();
                    });

                    // Form submission check
                    $('form').on('submit', function () {
                        updateHiddenInput();
                    });

                    // Initial update to ensure hidden input reflects current table state
                    updateHiddenInput();
                });
            </script>
        </td>
    </tr>
    <?php
}
add_action('woocommerce_admin_field_token_table', 'wc_omnixep_render_token_table_field');

/**
 * Display ElectraPay logo in footer if module is active
 */
function wc_omnixep_display_footer_logo()
{
    // Don't show in admin
    if (is_admin()) {
        return;
    }

    $settings = get_option('woocommerce_omnixep_settings', array());
    $enabled = isset($settings['enabled']) ? $settings['enabled'] : 'no';

    if ($enabled === 'yes') {
        $logo_url = plugins_url('electrapay.png', __FILE__);
        ?>
        <div class="omnixep-footer-logo" style="text-align: center; padding: 30px 0; width: 100%; clear: both;">
            <a href="https://shops.electraprotocol.com" target="_blank" rel="noopener">
                <img src="<?php echo esc_url($logo_url); ?>" alt="ElectraPay"
                    style="max-width: 125px; height: auto; display: inline-block; vertical-align: middle; filter: drop-shadow(0 2px 4px rgba(0,0,0,0.1)); transition: transform 0.3s ease;">
            </a>
            <style>
                .omnixep-footer-logo img:hover {
                    transform: scale(1.05);
                }
            </style>
        </div>
        <?php
    }
}
add_action('wp_footer', 'wc_omnixep_display_footer_logo', 20);

/**
 * Add "Platform" column to WooCommerce Orders List
 */
add_filter('manage_edit-shop_order_columns', 'wc_omnixep_add_platform_column'); // Legacy
add_filter('manage_woocommerce_page_wc-orders_columns', 'wc_omnixep_add_platform_column'); // HPOS
function wc_omnixep_add_platform_column($columns)
{
    $new_columns = array();
    foreach ($columns as $key => $column) {
        $new_columns[$key] = $column;
        if ($key === 'order_total' || $key === 'total') {
            $new_columns['omnixep_platform'] = 'Platform';
        }
    }
    return $new_columns;
}

/**
 * Populate "Platform" column in WooCommerce Orders List
 */
add_action('manage_shop_order_posts_custom_column', 'wc_omnixep_populate_platform_column', 10, 2); // Legacy
add_action('manage_woocommerce_page_wc-orders_custom_column', 'wc_omnixep_populate_platform_column_hpos', 10, 2); // HPOS

function wc_omnixep_populate_platform_column($column, $post_id)
{
    if ($column === 'omnixep_platform') {
        $order = wc_get_order($post_id);
        if ($order) {
            $platform = $order->get_meta('_omnixep_platform');
            if (empty($platform)) {
                // If not mobile, check if it's a web payment
                $txid = $order->get_meta('_omnixep_txid');
                if (!empty($txid)) {
                    echo '<span class="badge" style="background:#4dabf7;color:white;padding:3px 8px;border-radius:4px;font-size:11px;">Web / Extension</span>';
                } else {
                    echo '<span style="color:#adb5bd;">-</span>';
                }
            } else {
                $color = (strpos($platform, 'Android') !== false) ? '#a4c639' : ((strpos($platform, 'iOS') !== false) ? '#8e8e93' : '#4dabf7');
                echo '<span class="badge" style="background:' . $color . ';color:white;padding:3px 8px;border-radius:4px;font-size:11px;">' . esc_html($platform) . '</span>';
            }
        }
    }
}

function wc_omnixep_populate_platform_column_hpos($column, $order)
{
    if ($column === 'omnixep_platform') {
        $platform = $order->get_meta('_omnixep_platform');
        if (empty($platform)) {
            $txid = $order->get_meta('_omnixep_txid');
            if (!empty($txid)) {
                echo '<span class="badge" style="background:#4dabf7;color:white;padding:3px 8px;border-radius:4px;font-size:11px;">Web / Extension</span>';
            } else {
                echo '<span style="color:#adb5bd;">-</span>';
            }
        } else {
            $color = (strpos($platform, 'Android') !== false) ? '#a4c639' : ((strpos($platform, 'iOS') !== false) ? '#8e8e93' : '#4dabf7');
            echo '<span class="badge" style="background:' . $color . ';color:white;padding:3px 8px;border-radius:4px;font-size:11px;">' . esc_html($platform) . '</span>';
        }
    }
}
