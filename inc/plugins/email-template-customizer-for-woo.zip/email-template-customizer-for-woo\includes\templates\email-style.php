<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
    ul.wc-item-meta{padding:10px 0;}
<?php
