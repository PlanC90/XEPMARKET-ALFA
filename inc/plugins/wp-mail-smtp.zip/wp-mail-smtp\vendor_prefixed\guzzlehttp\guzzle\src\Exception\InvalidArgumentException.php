<?php

namespace WPMailSMTP\Vendor\GuzzleHttp\Exception;

final class InvalidArgumentException extends \InvalidArgumentException implements GuzzleException
{
}
