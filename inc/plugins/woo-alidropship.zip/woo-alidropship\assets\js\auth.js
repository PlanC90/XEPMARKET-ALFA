'use strict';
jQuery(document).ready(function ($) {
    let $form = $('.vi-wad-auth-form');
    if ($form.length > 0) {
        $form.submit();
    }
});